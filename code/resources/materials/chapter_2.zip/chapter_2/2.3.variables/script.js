


/*
Константа (const)
значение не может измениться
const button = document.querySelector('button');


Переменная (let)
значение может измениться
let word = 'hello';
word = 'Bye';


Преимущества констант и переменных:
1. Аккуратность кода
2. Хранение значений


Правила объявления переменной/константы, присвоение значения:
1. Имя
	A. В основном используется camelCase   (myNameIs)
	B. Цифры можно использовать, но первый символ не может с неё начинаться
	C. Из символов можно использовать только $ и _

2. Значения
	A. Буквы, символы, цифры (вместе с буквами-символами) должны быть в кавычках (const email = '1@t.com';) 
	B. Цифры - без кавычек (let age = 18;)
	C. Зарезервированные слова - без кавычек (const box = document.querySelector('b');)

3. Популярные ошибки
	А. Одинаковая переменная не может объявляться дважды
		неверно: 
		let name = 'vasya';
		let name = 'misha';
		верно:
		let name = 'vasya';
		name = 'misha';
	B. Вначале объявляем, потом используем
		неверно:
		title.textContent = 'Hello';
		const title = document.querySelector('h1');
		верно:
		const title = document.querySelector('h1');
		title.textContent = 'Hello';
*/



// Код из лекции
// const title = document.querySelector('h1');
// title.textContent = 'Hello';

// let text = 'Старт';
// text = 'Пуск';
// title.textContent = text;

// const button = document.querySelector('button');
// button.textContent = text;

// const countdown = document.querySelector('b');
// let count = 5;
// countdown.textContent = count;