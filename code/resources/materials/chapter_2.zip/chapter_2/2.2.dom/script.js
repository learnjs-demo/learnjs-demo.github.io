// document.querySelector('h1');


/*
DOM (Document Object Model)
объектная модель документа, которую браузер создаёт на основании HTML-кода, и позволяет получать доступ к елементам страницы с помощью JavaScript


Метод querySelector 
позволяет получить элемент по определённому CSS-селектору
document.querySelector('button');
или
document.querySelector("button");


myNameIs - верблюжий регистр (camelCase)


Свойство textContent
позволяет получить и изменить текст элемента
document.querySelector('button').textContent = 'Отправить';


Д.З.
1. Добавить несколько элементов в HTML-файл, которые могут содержать текст (h2,p,a,i,em,strong,span)
2. С помощью JavaScript изменить текст внутри них, обращаясь к разным видам селекторов (класс,идентификатор, элемент)


Комментарии в JavaScript
текст, написанный в коде, который не влияет на выполнение кода. Используется для добавления примечаний


Виды комментариев:
1. Однострочные
текст начинается с //
// document.querySelector('button');

2. Многострочные
текст между /* */
/*
document.querySelector('button');
document.querySelector('h2');
*/



// Код из лекции
// document.querySelector('h1').textContent = 'Hello';
// document.querySelector('.purple').textContent = 'Purple';
// document.querySelector('#blue').textContent = 'Blue';
// document.querySelector('b:first-child').textContent = 'Black';