const text = document.querySelector('p');
const img = document.querySelector('#image');

img.addEventListener('click', () => {
    img.src = 'img/found.png';
    text.textContent = 'Нашёл тебя!';
});



/*
Метод getElementById
возвращает элемент на основании значения в html-атрибуте id
document.getElementById('main');


Метод querySelector возвращает элемент на основании CSS-селектора (элемент, класс, идентификатор и т.д.)
document.querySelector('#main');
document.querySelector('.text-green');
document.querySelector('p');
*/



// Код из лекции
// const text = document.querySelector('p');
// const img = document.getElementById('image');

// img.addEventListener('click', () => {
//     img.src = 'img/found.png';
//     text.textContent = 'Нашёл тебя!';
// });