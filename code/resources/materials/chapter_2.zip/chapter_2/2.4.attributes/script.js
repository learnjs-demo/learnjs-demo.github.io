const title = document.querySelector('h1');
const input = document.querySelector('input');
const button = document.querySelector('button');

/*
Смена значений в атрибуте/Добавление атрибута 
элемент.атрибут = 'значение';
input.value = 'Hello world!';


Работа с атрибутом style
<h1 style="color: orange;">Атрибуты</h1>
title.style.color = 'orange';


CSS-свойства, написанные через тире, прописываются в верблюжьем регистре
title.style.fontSize = '23px';


Работа с пустыми (логическими) атрибутами
button.disabled = true;
button.disabled = false;


Булевый тип данных (Boolean) 
принимает два возможных значения: истина (true) или ложь (false)
const result = true;


Д.З.
1. Раскомментировать код в "index.html" - файле
2. В "script.js" - файле для b-элементов изменить текст в следующем порядке: Blue, Purple, Grey 
3. Для всех b-элементов добавить сплошную границу в 1px с #3e3e3e цветом
4. Для b-элементов изменить background-color в следующем порядке: #4084eb, #b550da, #818282
*/



// Код из лекции
// input.value = 'Bye';
// input.type = 'password';
// input.placeholder = 'Put some text';

// title.style = 'color: red;background: yellow;';
// title.style.color = 'green';
// title.style.border = '1px solid brown';
// title.style.fontSize = '45px';
// title.style.backgroundColor = 'pink';

// button.disabled = false;










/*
Пример решения Д.З.
const blueBox = document.querySelector('b:first-child');
const purpleBox = document.querySelector('.purple');
const greyBox = document.querySelector('#grey');

blueBox.textContent = 'Blue';
purpleBox.textContent = 'Purple';
greyBox.textContent = 'Grey';

blueBox.style.border = '1px solid #3e3e3e';
purpleBox.style.border = '1px solid #3e3e3e';
greyBox.style.border = '1px solid #3e3e3e';

blueBox.style.backgroundColor = '#4084eb';
purpleBox.style.backgroundColor = '#b550da';
greyBox.style.backgroundColor = '#818282';
*/