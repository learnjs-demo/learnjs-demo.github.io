const cat = document.querySelector('.cat');

document.querySelector('.cat').addEventListener('click', () => {
    
});

/*
Свойство className
отвечает за значение атрибута class
cat.className = 'cat-smile';

Данное свойство можно использовать для добавления 2+ класса
cat.className = 'cat black-cat cat-smile';


Методы classList
A. add
classList.add() - добавление класса
cat.classList.add('cat-smile');

B. remove
classList.remove() - удаление класса
cat.classList.remove('cat-smile');

C. toggle
classList.toggle() - переключение класса
cat.classList.toggle('cat-smile');
Если указанный класс отсутствует, он добавляется
Если данный класс есть, он удаляется


Д.З.
1. Раскомментировать код в "index.html"-файле
2. В "script.js"-файле, с помощью добавления и удаления класса, выстроить цвета в правильном порядке: blue, purple, green
*/



// Код из лекции
//cat.className = 'hello';
//cat.classList.add('cat-smile');
//cat.classList.remove('cat-smile');
//cat.classList.toggle('cat-smile');









/*
Пример решения Д.З.
const blueBox = document.querySelector('#blue');
const purpleBox = document.querySelector('#purple');
const greenBox = document.querySelector('#green');

blueBox.classList.remove('purple');
blueBox.classList.add('blue');

purpleBox.classList.remove('green');
purpleBox.classList.add('purple');

greenBox.classList.remove('blue');
greenBox.classList.add('green');
*/